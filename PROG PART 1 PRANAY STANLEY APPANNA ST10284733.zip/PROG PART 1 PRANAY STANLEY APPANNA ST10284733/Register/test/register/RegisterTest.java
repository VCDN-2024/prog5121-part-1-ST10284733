/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package register;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

/**
 *
 * @author lab_services_student
 */

public class RegisterTest {
    Register register = new Register();
    public RegisterTest() {
    }

   @org.junit.jupiter.api.Test
    // tests if the conditons are met
    public void testCheckUsernameMeetsTheCondtions() {
      String Actual = register.CheckUsername();
      String Expected = "Kyl_1";
      assertEquals(Expected, Actual);
      
    }
     @org.junit.jupiter.api.Test
    // tests if the are incorrect
    public void testCheckUsernameDoesNotMeetsTheCondtions() {
      String Actual2 = register.CheckUsername();
      String Expected2 = "Kyl!!!!";
      assertEquals(Expected2, Actual2);
      
    }

    @org.junit.jupiter.api.Test
    // tests if the condtions are met
    public void testCheckPasswordComplexityIsCorrect() {
        boolean Actual1 =register.checkPasswordComplexity();
        String Expected1= "Ch&&sec@ke99!";
        assertEquals(Expected1,Actual1);
    }
     @org.junit.jupiter.api.Test
    // tests if the condtions are  not met
    public void testCheckPasswordComplexityIsInCorrect() {
        boolean Actual1 =register.checkPasswordComplexity();
        String Expected1= "“password";
        assertEquals(Expected1,Actual1);
    }
    
 
    
}
